#!/bin/sh
#shebang line used to orient the file as a bash script 
echo "name a living organism"
#asks the user for input
read livingOrganism
#assigns the input to a variable

echo "name a verb ending in 'ing'"
#asks the user for input
read verbING
#assigns the input to a variable

echo "name a different living organism(plural)"
#asks the user for input
read livingOrganism2
#assigns the input to a variable

echo "pick a year"
#asks the user for input
read year
#assigns the input to a variable

echo "name an emotion enging in 'ed'"
#asks the user for input
read emotionED
#assigns the input to a variable

echo "name a dog's name"
#asks the user for input
read dogsName
#assigns the input to a variable

echo "name a different living organism"
#asks the user for input
read livingOrganism3
#assings the input to a variable

echo "name a different living organism"
#asks the user for input
read livingOrganism4
#assings the user input to a variable

echo "name an adjective ending in 'y'"
#asks the user for input
read adjectiveY
#assigns the input to a variable

echo "name a different adjective ending in 'y'"
#asks the user for input
read adjectiveY2
#assigns the input to a variable

echo "name a cutesy pet name"
#asks the user for input
read petName
#assigns the input to a variable

echo "name a disaster"
#asks the user for input
read disaster
#assigns the input to a variable

echo "name a famous person"
#asks the user for input
read famousPerson
#assings the input to a variable

echo "name an adjective ending in 'y'"
#asks the user for input
read adjectiveY3
#assings the input to a variable

echo "name a verb enging in 'ed'"
#asks the user for input
read verbED
#assigns the input to a variable

echo "pick a number"
#asks the user for input
read number
#assings the input to a variable

echo "name a different living organism (plural)"
#asks the user for input
read livingOrganism5
#assigns the input to a variable

echo "name a different living organism (plural)"
#asks the user for input
read livingOrganism6
#assings the input to a variable

echo "name a noun"
#asks the user for input
read noun
#assings the input to a variable

echo "name a different living organism (plural)"
#asks the user for input
read livingOrganism7
#assigns the input to a variable

echo "name a verb"
#asks the user for input
read verb
#assings the input to a variable

echo "A passion of mine has always been in $livingOrganism rescue.
I started $verbING animals (mostly $livingOrganism2) in $year because I was $emotionED
by the way that my dog $dogsName and I were treated due to $dogsName being a/an $livingOrganism3.
My first rescue $livingOrganism4 was Falkor. He was my $adjectiveY, $adjectiveY2 $petName!
I saved him from a/an $disaster right as he was knocking on $famousPerson's $adjectiveY3 door-step!
Since Falkor, I have $verbED $number $livingOrganism5 including 5 $livingOrganism6 in this month alone!
As a/an $noun who is passionate about $livingOrganism7, I will always $verb for those who can't."
#displays a written paragraph completed by the users input 
