#!/bin/sh
#orients the document to execute as a shell script
echo Hello World!
#displays the phrase "Hello World"
