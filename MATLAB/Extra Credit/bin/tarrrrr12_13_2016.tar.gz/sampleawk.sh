#/bin/sh

awk '/Dec/' GeekyHolidays.txt
