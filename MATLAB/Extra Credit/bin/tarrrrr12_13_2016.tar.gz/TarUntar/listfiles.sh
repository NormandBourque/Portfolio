#!/bin/sh
#shebang line orienting the document as a bash script
ls -l
#lists the files in the current directory
